import React from 'react';
import ItemForm from './components/ItemForm'; 
import './App.css';
// Adjust the path if necessary

function App() {
  return (
    <div className="App">
     
      <ItemForm />
    </div>
  );
}

export default App;
